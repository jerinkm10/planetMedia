// ChangePassword.js

import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
const ChangePassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'password') {
      setPassword(value);
    } else if (name === 'confirmPassword') {
      setConfirmPassword(value);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        'https://app.packreal.planetmedia.dev/api/change-password',
        {
          'currentPassword':password,
          'newPassword':confirmPassword,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
            'Content-Type': 'application/json', // Use application/json for JSON data
          },
        }
      );
      setMessage(response.data.message);
      // Optionally, you can redirect the user or show a success message
    } catch (error) {
      console.error('Error changing password:', error);
      setMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div>
    <h1>Change Password</h1>
      <section className="section profile">
        <div className="row">
          <div className="col-xl-4">
            <div className="card">
              
            </div>
          </div>

          <div className="col-xl-8">
            <div className="card">
              <div className="card-body pt-3">
                  <Link  className="col-3 pt-3 float-right" to="/dashboard">Account</Link>
                  <Link className="col-3 pt-3 mr-3 float-left" to="/change-password" style={{ marginLeft: '25px' }}>
                    Change Password
                  </Link>
                  <form onSubmit={handleSubmit}>
                    <label htmlFor="password">New Password:</label>
                    <input type="password" className="form-control mt-3" id="password" name="password" value={password} onChange={handleChange} required />
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input type="password" className="form-control mt-3" id="confirmPassword" name="confirmPassword" value={confirmPassword} onChange={handleChange} required />
                    <button type="submit">Change Password</button>
                  </form>
                  {message && <p>{message}</p>}
              </div>
            </div>
          </div>
        </div>
      </section>
  </div>
  );
};

export default ChangePassword;
