import React, { useEffect, useState } from 'react';
import { useAuth } from "../hooks/AuthProvider";
import axios from 'axios'; // Import axios for API requests
import Swal from 'sweetalert2';
import { Link } from 'react-router-dom';
const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    phone: '',
    website: '',
    photoId: null,
    logoId: null,
  });
  const auth = useAuth();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('https://app.packreal.planetmedia.dev/api/account', {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Include authorization token
          },
        });
        const userData = response.data;
        console.log(userData);
        setUser(userData);
        setFormData({
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          phone: userData.phone,
          website: userData.website,
          photoId: null, // Set to null initially
          logoId: null, // Set to null initially
        });
      } catch (error) {
        console.error('Error fetching user data:', error);
        // Handle error, such as redirecting to login page if unauthorized
        auth.logOut();
      }
    };

    fetchUserData(); // Fetch user data on component mount

    // Cleanup function
    return () => {
      // Cleanup tasks, if any
    };
  }, [auth]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files && files[0]) {
      // If file input is changed, update the formData with the selected file
      setFormData((prevData) => ({
        ...prevData,
        [name]: files[0],
      }));
    } else {
      // If it's not a file input, update the formData with the value
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const handleUpdate = async () => {
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('email', formData.email);
      formDataToSend.append('firstName', formData.firstName);
      formDataToSend.append('lastName', formData.lastName);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('website', formData.website);
      formDataToSend.append('photoId', formData.photoId);
      formDataToSend.append('logoId', formData.logoId);

      const response = await axios.post('https://app.packreal.planetmedia.dev/api/account', formDataToSend, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Include authorization token
          'Content-Type': 'multipart/form-data', // Set content type for file upload
        },
      });
      console.log('Update success:', response.data);
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Data updated successfully.',
      });
      // Optionally, update local state or show a success message
    } catch (error) {
      console.error('Error updating data:', error);
      // Handle error, such as displaying an error message
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
      });
    }
  };

  return (
    <div>
    <h1>Account</h1>
    
    {user ? (
      <section className="section profile">
        <div className="row">
          <div className="col-xl-4">
            <div className="card">
              <div className="card-body profile-card pt-4 d-flex flex-column align-items-center">
                <img src={user.photo} alt="Profile" className="rounded-circle" />
                <h2>{user.firstName} {user.lastName}</h2>
                <h3>{user.companyName}</h3>
                <div className="social-links mt-2">
                  <a href="#" className="twitter"><i className="bi bi-twitter"></i></a>
                  <a href="#" className="facebook"><i className="bi bi-facebook"></i></a>
                  <a href="#" className="instagram"><i className="bi bi-instagram"></i></a>
                  <a href="#" className="linkedin"><i className="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div className="col-xl-8">
            <div className="card">
              <div className="card-body pt-3">
                  <Link  className="col-3 pt-3 float-right" to="/dashboard">Account</Link>
                  <Link className="col-3 pt-3 mr-3 float-left" to="/change-password" style={{ marginLeft: '25px' }}>
                    Change Password
                  </Link>
                  <input type="text" className="form-control mt-3" name="email" value={formData.email} onChange={handleChange} />
                  <input type="text" className="form-control mt-3" name="firstName" value={formData.firstName} onChange={handleChange} />
                  <input type="text" className="form-control mt-3" name="lastName" value={formData.lastName} onChange={handleChange} />
                  <input type="text" className="form-control mt-3" name="phone" value={formData.phone} onChange={handleChange} />
                  <input type="text" className="form-control mt-3" name="website" value={formData.website} onChange={handleChange} />
                  {/* File input for photoId */}
                  <input type="file" className="form-control mt-3" name="photoId" onChange={handleChange} />
                  {/* File input for logoId */}
                  <input type="file" className="form-control mt-3" name="logoId" onChange={handleChange} />
                  {/* Other input fields */}
                  <button onClick={handleUpdate} className="btn btn-primary btn-submit  mr-3 mt-3">
                    Update Data
                  </button>
                  <button onClick={() => auth.logOut()} className="btn btn-primary btn-submit mr-3 mt-3">
                    Logout
                  </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    ) : (
      <p>Loading user data...</p>
    )}
  </div>
  );
};

export default Dashboard;
